# sklearn_mochine_learning
使用sklearn实现机器学习的算法，包括了线性回归、岭回归、逻辑回归、朴素贝叶斯、决策树、随机森林
